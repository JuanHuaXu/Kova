# Kova OpenClaw Runtime Report

> **❌ [FAIL]** — gateway-rpc pre-provider work dominated agent turn (94% of 4020ms)

## Verdict

| Field | Value |
|---|---|
| Verdict | FAIL |
| Reason | gateway-rpc pre-provider work dominated agent turn (94% of 4020ms) |
| Blocking findings | 7 |
| Warnings | 0 |
| Records | 10 (PASS:7, FAIL:3) |

## Proof Completeness

- Completeness: complete: 10
- Required obligations: 134 total, 0 missing, 1 failed
- Categories: command: 72, invariant: 42, artifact: 10, cleanup: 10

| Scenario | Obligation | Status | Reason |
|---|---|---|---|
| openai-compatible-turn | command:openai-compatible-turn:1 | failed | command exited 1 |

## Run

| Field | Value |
|---|---|
| Run ID | `kova-260528-030802-0ca629` |
| Generated | 2026-05-28T03:11:01.625Z |
| Mode | execution |
| Target | `npm:2026.5.26` |
| Platform | linux 6.8.0-79-generic (x64) · v22.19.0 |
| Repeat / parallel | 1 / 1 |
| Auth | unknown |

## Coverage

| Field | Value |
|---|---:|
| Records | 10 |
| Scenarios | 10 |
| States | 5 |
| PASS | 7 |
| FAIL | 3 |

## Findings

| Severity | Area | Scenario | Finding | Evidence |
|---|---|---|---|---|
| diagnostic-gap | OpenClaw | fresh-install/fresh | 3 expected OpenClaw diagnostics span(s) were not observed; user-path verdict is based on functional and performance checks | missing spans: gateway.startup, plugins.metadata, providers.list |
| diagnostic-gap | OpenClaw | gateway-performance/many-bundled-plugins | 3 expected OpenClaw diagnostics span(s) were not observed; user-path verdict is based on functional and performance checks | missing spans: gateway.startup, health.ready, eventLoop.delay |
| fail | OpenClaw | agent-gateway-rpc-turn/mock-openai-provider | gateway-rpc pre-provider work dominated agent turn (94% of 4020ms) | readinessHealthReadyMs: 3497; readinessListeningMs: 2266 |
| fail | OpenClaw | openai-compatible-turn/mock-openai-provider | agent message command finished without a usable assistant response | readinessHealthReadyMs: 3568; readinessListeningMs: 2267 |
| fail | OpenClaw | openai-compatible-turn/mock-openai-provider | openai-compatible agent turn did not produce the expected assistant response | readinessHealthReadyMs: 3568; readinessListeningMs: 2267 |
| fail | OpenClaw | openai-compatible-turn/mock-openai-provider | openai-compatible agent turn response did not exactly match expected text KOVA_AGENT_OK | readinessHealthReadyMs: 3568; readinessListeningMs: 2267 |
| fail | OpenClaw | openai-compatible-turn/mock-openai-provider | openai-compatible agent turn ran with mock auth but no mock provider request was captured | readinessHealthReadyMs: 3568; readinessListeningMs: 2267 |
| fail | OpenClaw | openai-compatible-turn/mock-openai-provider | No provider request happened during the agent turn. | readinessHealthReadyMs: 3568; readinessListeningMs: 2267 |
| diagnostic-gap | OpenClaw | openai-compatible-turn/mock-openai-provider | 5 expected OpenClaw diagnostics span(s) were not observed; user-path verdict is based on functional and performance checks | missing spans: agent.turn, agent.prepare, models.catalog, provider.request, agent.cleanup |
| diagnostic-gap | OpenClaw | bundled-runtime-deps/missing-plugin-index | 3 expected OpenClaw diagnostics span(s) were not observed; user-path verdict is based on functional and performance checks | missing spans: runtimeDeps.stage, plugins.runtimeDeps, plugins.runtimeDeps.install |
| diagnostic-gap | OpenClaw | bundled-plugin-startup/fresh | 2 expected OpenClaw diagnostics span(s) were not observed; user-path verdict is based on functional and performance checks | missing spans: plugins.metadata, plugins.runtimeDeps |
| fail | OpenClaw | plugin-lifecycle/plugin-index | final gateway state was restarting | readinessHealthReadyMs: 481; readinessListeningMs: 0 |
| info | Kova | report | 1 additional finding(s) omitted from Markdown | see summary JSON |

## Performance Summary

| Scenario | Samples | Status | Health Ready | Gateway RSS | Tracked RSS | CPU | Cold Turn | Warm Turn | Cold Pre-Provider |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|
| release-runtime-startup/fresh | 1 | PASS:1 | 3240ms | 511.7MB | unknown | 135% | unknown | unknown | unknown |
| fresh-install/fresh | 1 | PASS:1 | 3146ms | 522MB | unknown | 164% | unknown | unknown | unknown |
| gateway-performance/many-bundled-plugins | 1 | PASS:1 | 2987ms | 524MB | unknown | 151% | unknown | unknown | unknown |
| gateway-session-send-turn/mock-openai-provider | 1 | PASS:1 | 3577ms | unknown | unknown | 131% | 2078ms | 609ms | 1722ms |
| agent-cold-warm-message/mock-openai-provider | 1 | PASS:1 | unknown | 0MB | unknown | 182.4% | 5614ms | 5312ms | 5287ms |
| agent-gateway-rpc-turn/mock-openai-provider | 1 | FAIL:1 | 3497ms | 546.5MB | unknown | 160.8% | 4020ms | unknown | 3790ms |
| openai-compatible-turn/mock-openai-provider | 1 | FAIL:1 | 3568ms | 485.3MB | unknown | 138% | 205ms | unknown | unknown |
| bundled-runtime-deps/missing-plugin-index | 1 | PASS:1 | 3225ms | 480.5MB | unknown | 151% | unknown | unknown | unknown |
| bundled-plugin-startup/fresh | 1 | PASS:1 | 10ms | 523.2MB | unknown | 134% | unknown | unknown | unknown |
| plugin-lifecycle/plugin-index | 1 | FAIL:1 | 481ms | 485MB | unknown | 140% | unknown | unknown | unknown |

## Samples

| Sample | Status | Scenario | Health Ready | Gateway RSS | Tracked RSS | Cold Turn | Warm Turn | Blocker |
|---:|---|---|---:|---:|---:|---:|---:|---|
| 1 | PASS | release-runtime-startup/fresh | 3240ms | 511.7 MB | 797.2 MB | unknown | unknown |  |
| 1 | PASS | fresh-install/fresh | 3146ms | 522 MB | 863.5 MB | unknown | unknown |  |
| 1 | PASS | gateway-performance/many-bundled-plugins | 2987ms | 524 MB | 875.8 MB | unknown | unknown |  |
| 1 | PASS | gateway-session-send-turn/mock-openai-provider | 3577ms | 564.9 MB | 843.1 MB | 2078ms | 609ms |  |
| 1 | PASS | agent-cold-warm-message/mock-openai-provider | unknown | 0 MB | 624.6 MB | 5614ms | 5312ms |  |
| 1 | FAIL | agent-gateway-rpc-turn/mock-openai-provider | 3497ms | 546.5 MB | 1012.9 MB | 4020ms | unknown | gateway-rpc pre-provider work dominated agent turn (94% of 4020ms) |
| 1 | FAIL | openai-compatible-turn/mock-openai-provider | 3568ms | 485.3 MB | 507.3 MB | 205ms | unknown | agent message command finished without a usable assistant response |
| 1 | PASS | bundled-runtime-deps/missing-plugin-index | 3225ms | 480.5 MB | 486.4 MB | unknown | unknown |  |
| 1 | PASS | bundled-plugin-startup/fresh | 10ms | 523.2 MB | 598.6 MB | unknown | unknown |  |
| 1 | FAIL | plugin-lifecycle/plugin-index | 481ms | 485 MB | 642.1 MB | unknown | unknown | final gateway state was restarting |

## Resource Roles

- command-tree: RSS 624.6 MB; CPU 185.6%; scenario agent-cold-warm-message/mock-openai-provider
- agent-cli: RSS 624.6 MB; CPU 182.4%; scenario agent-cold-warm-message/mock-openai-provider
- agent-process: RSS 624.6 MB; CPU 182.4%; scenario agent-cold-warm-message/mock-openai-provider
- gateway: RSS 564.9 MB; CPU 164%; scenario gateway-session-send-turn/mock-openai-provider
- gateway-tree: RSS 564.9 MB; CPU 164%; scenario gateway-session-send-turn/mock-openai-provider
- model-cli: RSS 351.8 MB; CPU 177.5%; scenario gateway-performance/many-bundled-plugins
- status-cli: RSS 304.1 MB; CPU 185.6%; scenario gateway-performance/many-bundled-plugins
- plugin-cli: RSS 280.4 MB; CPU 171.6%; scenario fresh-install/fresh

## Selected Sample Details

### gateway-session-send-turn sample 1

- Status: PASS
- Cleanup: destroyed
- Artifact root: /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-gateway-session-send-tu-2f93edae-kova-260528-030802-0ca629
Measurements:
- startup: listening 2266ms; health 3577ms; readiness ready; gateway running; restarts 0
- health: startup p95 1311ms; post-ready p95 3ms; failures 9; final failures 0; slowest startup-sample/gateway-start 1311ms
- resources: gateway RSS 564.9 MB; tracked total 843.1 MB; max CPU 131%; samples 13; roles gateway 564.9MB/131%, gateway-tree 564.9MB/131%, command-tree 278.2MB/185.6%, status-cli 278.2MB/185.6%
- agent: turn 2078ms; cold/warm 2078ms/609ms; cold-warm delta 1469ms; pre-provider 1722ms; provider 10ms; metadata scans 4 (153.57ms); event-loop unknown; polls 6; cleanup unknown; diagnosis agent-latency-attributed; leaks 0
- Agent turn stats: count 2; p95 2004.55ms; max 2078ms; pre-provider p95 1664.65ms
- gateway session attribution: cold known 1699ms / unattributed 23ms; warm known 488ms / unattributed 87ms
- plugins/runtime: missing deps 0; plugin failures 0; runtime deps unknown; warm restages unknown; warm reuse unknown
- diagnostics: timeline available; slowest span gateway.chat_send.dispatch_inbound 1883.96ms; embedded traces 0; liveness warnings 0; open spans 0 (0 required); node CPU/heap/trace 0/0/0
- Agent turns:
  - cold: total 2078ms; pre-provider 1722ms; provider 10ms; post-provider 346ms; response true
    - gateway session: transport direct-gateway-rpc; create true; session create 438ms; send 21ms; first assistant 2078ms; matched assistant 2078ms; polls 4 (0 errors)
    - active window: metadata scans 3 (153.48ms total, max 83.3ms); event-loop samples 0 max unknown
    - breakdown: pre-provider 1722ms; provider 10ms; post-provider 346ms; unknown 1722ms; source none
  - warm: total 609ms; pre-provider 575ms; provider 2ms; post-provider 32ms; response true
    - gateway session: transport direct-gateway-rpc; create false; session create n/a; send 87ms; first assistant 609ms; matched assistant 609ms; polls 2 (0 errors)
    - active window: metadata scans 1 (0.09ms total, max 0.09ms); event-loop samples 0 max unknown
    - breakdown: pre-provider 575ms; provider 2ms; post-provider 32ms; unknown 575ms; source none
- Gateway session pre-provider attribution:
  - Spans are selected by active turn timestamp window; timeline phase is descriptive, not a startup/turn classifier.

  | turn | pre-provider | known | unattributed | provider | timeline |
  |---|---:|---:|---:|---:|---|
  | cold | 1722 ms | 1699 ms | 23 ms | 10 ms | /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-gateway-session-send-tu-2f93edae-kova-260528-030802-0ca629/openclaw/timeline.jsonl |
  | warm | 575 ms | 488 ms | 87 ms | 2 ms | /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-gateway-session-send-tu-2f93edae-kova-260528-030802-0ca629/openclaw/timeline.jsonl |

  | turn | span | phase(s) | count | errors | clipped | max |
  |---|---|---|---:|---:|---:|---:|
  | cold | `gateway.chat_send.dispatch_inbound` | `agent-turn` | 1 | 0 | 1699 ms | 1699 ms |
  | cold | `auto_reply.dispatch_reply_from_config` | `agent-turn` | 1 | 0 | 1698 ms | 1698 ms |
  | cold | `reply.run_reply_resolver` | `agent-turn` | 1 | 0 | 1541 ms | 1541 ms |
  | cold | `reply.run_prepared_reply` | `agent-turn` | 1 | 0 | 1153 ms | 1153 ms |
  | cold | `reply.run_agent_turn` | `agent-turn` | 1 | 0 | 894 ms | 894 ms |
  | cold | `reply.handle_inline_actions` | `agent-turn` | 1 | 0 | 248 ms | 248 ms |
  | warm | `auto_reply.dispatch_reply_from_config` | `agent-turn` | 1 | 0 | 488 ms | 488 ms |
  | warm | `gateway.chat_send.dispatch_inbound` | `agent-turn` | 1 | 0 | 488 ms | 488 ms |
  | warm | `reply.run_reply_resolver` | `agent-turn` | 1 | 0 | 483 ms | 483 ms |
  | warm | `reply.run_prepared_reply` | `agent-turn` | 1 | 0 | 429 ms | 429 ms |
  | warm | `reply.run_agent_turn` | `agent-turn` | 1 | 0 | 418 ms | 418 ms |
  | warm | `reply.resolve_directives` | `agent-turn` | 1 | 0 | 35 ms | 35 ms |

### agent-cold-warm-message sample 1

- Status: PASS
- Cleanup: destroyed
- Artifact root: /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-agent-cold-warm-message-2c26dd1d-kova-260528-030802-0ca629
Measurements:
- startup: listening unknown; health unknown; readiness unknown; gateway disabled; restarts 0
- health: startup p95 unknown; post-ready p95 unknown; failures 0; final failures 0
- resources: tracked total RSS 624.6 MB; tracked total 624.6 MB; max CPU 182.4%; samples 18; roles agent-cli 624.6MB/182.4%, agent-process 624.6MB/182.4%, command-tree 624.6MB/182.4%, status-cli 301.2MB/172.8%
- agent: turn 5614ms; cold/warm 5614ms/5312ms; cold-warm delta 302ms; pre-provider 5287ms; provider 4ms; metadata scans 64 (1032.75ms); event-loop unknown; polls 0; cleanup unknown; diagnosis agent-latency-attributed; leaks 0
- Agent turn stats: count 2; p95 5598.9ms; max 5614ms; pre-provider p95 5273.6ms
- agent CLI attribution: cold known 537ms / unattributed 4750ms; warm known 496ms / unattributed 4523ms
- plugins/runtime: missing deps 0; plugin failures 0; runtime deps unknown; warm restages unknown; warm reuse unknown
- diagnostics: timeline available; slowest span plugins.metadata.scan 118.19ms; embedded traces 0; liveness warnings 0; open spans 0 (0 required); node CPU/heap/trace 0/0/0
- Agent turns:
  - cold: total 5614ms; pre-provider 5287ms; provider 4ms; post-provider 323ms; response true
    - active window: metadata scans 32 (537.65ms total, max 109.52ms); event-loop samples 0 max unknown
    - breakdown: pre-provider 5287ms; provider 4ms; post-provider 323ms; unknown 5287ms; source none
  - warm: total 5312ms; pre-provider 5019ms; provider 5ms; post-provider 288ms; response true
    - active window: metadata scans 32 (495.1ms total, max 108.26ms); event-loop samples 0 max unknown
    - breakdown: pre-provider 5019ms; provider 5ms; post-provider 288ms; unknown 5019ms; source none
- Agent CLI pre-provider attribution:
  - Spans are selected by active turn timestamp window; timeline phase is descriptive, not a startup/turn classifier.

  | turn | pre-provider | known | unattributed | provider | timeline |
  |---|---:|---:|---:|---:|---|
  | cold | 5287 ms | 537 ms | 4750 ms | 4 ms | /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-agent-cold-warm-message-2c26dd1d-kova-260528-030802-0ca629/openclaw/timeline.jsonl |
  | warm | 5019 ms | 496 ms | 4523 ms | 5 ms | /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-agent-cold-warm-message-2c26dd1d-kova-260528-030802-0ca629/openclaw/timeline.jsonl |

  | turn | span | phase(s) | count | errors | clipped | max |
  |---|---|---|---:|---:|---:|---:|
  | cold | `plugins.metadata.scan` | `startup` x8 | 8 | 0 | 537 ms | 110 ms |
  | warm | `plugins.metadata.scan` | `startup` x11 | 11 | 0 | 496 ms | 108 ms |

### agent-gateway-rpc-turn sample 1

- Status: FAIL
- Cleanup: destroyed
- Artifact root: /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-agent-gateway-rpc-turn-1a20d57e-kova-260528-030802-0ca629
Measurements:
- startup: listening 2266ms; health 3497ms; readiness ready; gateway running; restarts 0
- health: startup p95 1231ms; post-ready p95 9ms; failures 9; final failures 0; slowest startup-sample/gateway-start 1231ms
- resources: agent-cli RSS 471.2 MB; tracked total 1012.9 MB; max CPU 160.8%; samples 13; roles gateway 546.5MB/150%, gateway-tree 546.5MB/150%, agent-cli 471.2MB/160.8%, agent-process 471.2MB/160.8%
- agent: turn 4020ms; cold/warm 4020ms/unknown; cold-warm delta unknown; pre-provider 3790ms; provider 3ms; metadata scans 11 (253.55ms); event-loop 0ms; polls 0; cleanup unknown; diagnosis agent-latency-attributed; leaks 0
- Agent turn stats: count 1; p95 4020ms; max 4020ms; pre-provider p95 3790ms
- agent CLI attribution: cold known unknown / unattributed unknown; warm known unknown / unattributed unknown
- plugins/runtime: missing deps 0; plugin failures 0; runtime deps unknown; warm restages unknown; warm reuse unknown
- diagnostics: timeline available; slowest span gateway.ready 1372.51ms; embedded traces 0; liveness warnings 0; open spans 0 (0 required); node CPU/heap/trace 0/0/0
- Violations:
  - gateway-rpc pre-provider work dominated agent turn (94% of 4020ms)
- Agent turns:
  - gateway-rpc: total 4020ms; pre-provider 3790ms; provider 3ms; post-provider 227ms; response true
    - active window: metadata scans 11 (253.55ms total, max 124.36ms); event-loop samples 7 max 0ms
    - breakdown: pre-provider 3790ms; provider 3ms; post-provider 227ms; unknown 3790ms; source none
- Agent CLI pre-provider attribution:
  - Spans are selected by active turn timestamp window; timeline phase is descriptive, not a startup/turn classifier.

  | turn | pre-provider | known | unattributed | provider | timeline |
  |---|---:|---:|---:|---:|---|
  | gateway-rpc | 3790 ms | 255 ms | 3535 ms | 3 ms | /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-agent-gateway-rpc-turn-1a20d57e-kova-260528-030802-0ca629/openclaw/timeline.jsonl |

  | turn | span | phase(s) | count | errors | clipped | max |
  |---|---|---|---:|---:|---:|---:|
  | gateway-rpc | `plugins.metadata.scan` | `startup` x6 | 6 | 0 | 255 ms | 124 ms |

### openai-compatible-turn sample 1

- Status: FAIL
- Cleanup: destroyed
- Artifact root: /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-openai-compatible-turn-4993d818-kova-260528-030802-0ca629
Measurements:
- startup: listening 2267ms; health 3568ms; readiness ready; gateway running; restarts 0
- health: startup p95 1301ms; post-ready p95 unknown; failures 9; final failures 0; slowest startup-sample/gateway-start 1301ms
- resources: gateway RSS 485.3 MB; tracked total 507.3 MB; max CPU 138%; samples 6; roles gateway 485.3MB/138%, gateway-tree 485.3MB/138%, command-tree 22MB/0%, openai-compatible-client 22MB/0%
- agent: turn 205ms; cold/warm 205ms/unknown; cold-warm delta unknown; pre-provider unknown; provider unknown; metadata scans 0 (0ms); event-loop unknown; polls 0; cleanup unknown; diagnosis no-provider-request; leaks 0
- Agent turn stats: count 1; p95 205ms; max 205ms; pre-provider p95 unknown
- plugins/runtime: missing deps 0; plugin failures 0; runtime deps unknown; warm restages unknown; warm reuse unknown
- diagnostics: timeline available; slowest span gateway.ready 1433.17ms; embedded traces 0; liveness warnings 0; open spans 0 (0 required); node CPU/heap/trace 0/0/0
- Violations:
  - agent message command finished without a usable assistant response
  - openai-compatible agent turn did not produce the expected assistant response
  - openai-compatible agent turn response did not exactly match expected text KOVA_AGENT_OK
  - openai-compatible agent turn ran with mock auth but no mock provider request was captured
  - No provider request happened during the agent turn.
- Failed command: `node '/home/gideon/kova-remote-runs/kova-20260528-G95R75'/support/run-openai-compatible...`
- Failure: OpenAI-compatible HTTP 404: Not Found
- Agent turns:
  - openai-compatible: total 205ms; pre-provider unknown; provider unknown; post-provider unknown; response false
    - active window: metadata scans 0 (0ms total, max unknown); event-loop samples 0 max unknown
    - breakdown: pre-provider 0ms; provider 0ms; post-provider 0ms; unknown 0ms; source none

### plugin-lifecycle sample 1

- Status: FAIL
- Cleanup: destroyed
- Artifact root: /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-plugin-lifecycle-plugin-e786a941-kova-260528-030802-0ca629
Measurements:
- startup: listening 0ms; health 481ms; readiness ready; gateway restarting; restarts 6
- health: startup p95 481ms; post-ready p95 unknown; failures 0; final failures 0; slowest startup-sample/baseline 481ms
- resources: gateway RSS 485 MB; tracked total 642.1 MB; max CPU 140%; samples 10; roles gateway 485MB/140%, gateway-tree 485MB/140%, command-tree 280.3MB/138.8%, plugin-cli 280.3MB/138.8%
- agent: turn not-run; cold/warm unknown/unknown; cold-warm delta unknown; pre-provider unknown; provider unknown; metadata scans 0 (0ms); event-loop unknown; polls 0; cleanup unknown; diagnosis unknown; leaks 0
- Agent turn stats: count 0; p95 unknown; max unknown; pre-provider p95 unknown
- plugins/runtime: missing deps 0; plugin failures 0; runtime deps unknown; warm restages 0; warm reuse true
- diagnostics: timeline available; slowest span gateway.ready 1323.97ms; embedded traces 0; liveness warnings 0; open spans 0 (0 required); node CPU/heap/trace 0/0/0
- Violations:
  - final gateway state was restarting

## Artifacts

- markdown-report: /home/gideon/kova-remote-runs/kova-20260528-G95R75/reports-web-release-1/kova-260528-030802-0ca629-web-release.md
- json-report: /home/gideon/kova-remote-runs/kova-20260528-G95R75/reports-web-release-1/kova-260528-030802-0ca629-web-release.json
- summary-json: /home/gideon/kova-remote-runs/kova-20260528-G95R75/reports-web-release-1/kova-260528-030802-0ca629-web-release.summary.json
- collector-root release-runtime-startup#1: /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-release-runtime-startup-c86ef85d-kova-260528-030802-0ca629
- collector-root fresh-install#1: /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-fresh-install-fresh-8da406d9-kova-260528-030802-0ca629
- collector-root gateway-performance#1: /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-gateway-performance-man-d48bd949-kova-260528-030802-0ca629
- collector-root gateway-session-send-turn#1: /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-gateway-session-send-tu-2f93edae-kova-260528-030802-0ca629
- collector-root agent-cold-warm-message#1: /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-agent-cold-warm-message-2c26dd1d-kova-260528-030802-0ca629
- collector-root agent-gateway-rpc-turn#1: /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-agent-gateway-rpc-turn-1a20d57e-kova-260528-030802-0ca629
- collector-root openai-compatible-turn#1: /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-openai-compatible-turn-4993d818-kova-260528-030802-0ca629
- collector-root bundled-runtime-deps#1: /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-bundled-runtime-deps-mi-48fdf9ad-kova-260528-030802-0ca629
- collector-root bundled-plugin-startup#1: /home/gideon/.kova/artifacts/kova-260528-030802-0ca629/kova-bundled-plugin-startup-35f8b7d8-kova-260528-030802-0ca629
- 1 additional artifact reference(s) omitted from Markdown. See summary JSON.

